from typing import Any, TypedDict

from ..exceptions import (
    DependencyViolationError,
    InvalidNetworkAclIdError,
    InvalidRouteTableIdError,
    NetworkAclEntryAlreadyExistsError,
)
from ..utils import (
    generic_filter,
    random_network_acl_id,
    random_network_acl_subnet_association_id,
)
from .core import TaggedEC2Resource


class NetworkAclBackend:
    def __init__(self) -> None:
        self.network_acls: dict[str, NetworkAcl] = {}

    def get_network_acl(self, network_acl_id: str) -> "NetworkAcl":
        network_acl = self.network_acls.get(network_acl_id, None)
        if not network_acl:
            raise InvalidNetworkAclIdError(network_acl_id)
        return network_acl

    def create_network_acl(
        self,
        vpc_id: str,
        tags: list[dict[str, str]] | None = None,
        default: bool = False,
    ) -> "NetworkAcl":
        network_acl_id = random_network_acl_id()
        self.get_vpc(vpc_id)  # type: ignore[attr-defined]
        network_acl = NetworkAcl(self, network_acl_id, vpc_id, default)
        for tag in tags or []:
            network_acl.add_tag(tag["Key"], tag["Value"])
        self.network_acls[network_acl_id] = network_acl
        if default:
            self.add_default_entries(network_acl_id)
        return network_acl

    def add_default_entries(self, network_acl_id: str) -> None:
        class AclEntry(TypedDict):
            rule_number: int
            rule_action: str
            egress: bool

        default_acl_entries: list[AclEntry] = [
            {"rule_number": 100, "rule_action": "allow", "egress": True},
            {"rule_number": 32767, "rule_action": "deny", "egress": True},
            {"rule_number": 100, "rule_action": "allow", "egress": False},
            {"rule_number": 32767, "rule_action": "deny", "egress": False},
        ]
        for entry in default_acl_entries:
            self.create_network_acl_entry(
                network_acl_id=network_acl_id,
                rule_number=entry["rule_number"],
                protocol="-1",
                rule_action=entry["rule_action"],
                egress=entry["egress"],
                cidr_block="0.0.0.0/0",
                icmp_code=None,
                icmp_type=None,
                port_range_from=None,
                port_range_to=None,
                ipv6_cidr_block=None,
            )

    def delete_network_acl(self, network_acl_id: str) -> "NetworkAcl":
        if any(
            network_acl.id == network_acl_id and len(network_acl._associations) > 0
            for network_acl in self.network_acls.values()
        ):
            raise DependencyViolationError(
                f"The network ACL '{network_acl_id}' has dependencies and cannot be deleted."
            )

        deleted = self.network_acls.pop(network_acl_id, None)
        if not deleted:
            raise InvalidNetworkAclIdError(network_acl_id)
        return deleted

    def create_network_acl_entry(
        self,
        network_acl_id: str,
        rule_number: int,
        protocol: str,
        rule_action: str,
        egress: bool,
        cidr_block: str,
        icmp_code: int | None,
        icmp_type: int | None,
        port_range_from: int | None,
        port_range_to: int | None,
        ipv6_cidr_block: str | None,
    ) -> "NetworkAclEntry":
        network_acl = self.get_network_acl(network_acl_id)
        if any(
            entry.egress == egress and entry.rule_number == rule_number
            for entry in network_acl.network_acl_entries
        ):
            raise NetworkAclEntryAlreadyExistsError(rule_number)
        network_acl_entry = NetworkAclEntry(
            self,
            network_acl_id=network_acl_id,
            rule_number=rule_number,
            protocol=protocol,
            rule_action=rule_action,
            egress=egress,
            cidr_block=cidr_block,
            icmp_code=icmp_code,
            icmp_type=icmp_type,
            port_range_from=port_range_from,
            port_range_to=port_range_to,
            ipv6_cidr_block=ipv6_cidr_block,
        )

        network_acl.network_acl_entries.append(network_acl_entry)
        return network_acl_entry

    def delete_network_acl_entry(
        self, network_acl_id: str, rule_number: int, egress: bool
    ) -> "NetworkAclEntry":
        network_acl = self.get_network_acl(network_acl_id)
        entry = next(
            entry
            for entry in network_acl.network_acl_entries
            if entry.egress == egress and entry.rule_number == rule_number
        )
        if entry is not None:
            network_acl.network_acl_entries.remove(entry)
        return entry

    def replace_network_acl_entry(
        self,
        network_acl_id: str,
        rule_number: int,
        protocol: str,
        rule_action: str,
        egress: bool,
        cidr_block: str,
        icmp_code: int,
        icmp_type: int,
        port_range_from: int,
        port_range_to: int,
        ipv6_cidr_block: str | None,
    ) -> "NetworkAclEntry":
        self.delete_network_acl_entry(network_acl_id, rule_number, egress)
        network_acl_entry = self.create_network_acl_entry(
            network_acl_id=network_acl_id,
            rule_number=rule_number,
            protocol=protocol,
            rule_action=rule_action,
            egress=egress,
            cidr_block=cidr_block,
            icmp_code=icmp_code,
            icmp_type=icmp_type,
            port_range_from=port_range_from,
            port_range_to=port_range_to,
            ipv6_cidr_block=ipv6_cidr_block,
        )
        return network_acl_entry

    def replace_network_acl_association(
        self, association_id: str, network_acl_id: str
    ) -> "NetworkAclAssociation":
        # lookup existing association for subnet and delete it
        default_acl = next(
            value
            for key, value in self.network_acls.items()
            if association_id in value._associations.keys()
        )

        subnet_id = None
        for key in default_acl._associations:
            if key == association_id:
                subnet_id = default_acl._associations[key].subnet_id
                del default_acl._associations[key]
                break

        new_assoc_id = random_network_acl_subnet_association_id()
        association = NetworkAclAssociation(
            self, new_assoc_id, subnet_id, network_acl_id
        )
        new_acl = self.get_network_acl(network_acl_id)
        new_acl._associations[new_assoc_id] = association
        return association

    def associate_default_network_acl_with_subnet(
        self, subnet_id: str, vpc_id: str
    ) -> None:
        association_id = random_network_acl_subnet_association_id()
        acl = next(
            acl
            for acl in self.network_acls.values()
            if acl.default and acl.vpc_id == vpc_id
        )
        acl._associations[association_id] = NetworkAclAssociation(
            self, association_id, subnet_id, acl.id
        )

    def describe_network_acls(
        self, network_acl_ids: list[str] | None = None, filters: Any = None
    ) -> list["NetworkAcl"]:
        network_acls = list(self.network_acls.values())

        if network_acl_ids:
            network_acls = [
                network_acl
                for network_acl in network_acls
                if network_acl.id in network_acl_ids
            ]
            if len(network_acls) != len(network_acl_ids):
                invalid_id = list(
                    set(network_acl_ids).difference(
                        {network_acl.id for network_acl in network_acls}
                    )
                )[0]
                raise InvalidRouteTableIdError(invalid_id)

        return generic_filter(filters, network_acls)


class NetworkAclAssociation:
    def __init__(
        self,
        ec2_backend: Any,
        new_association_id: str,
        subnet_id: str | None,
        network_acl_id: str,
    ):
        self.ec2_backend = ec2_backend
        self.id = new_association_id
        self.new_association_id = new_association_id
        self.subnet_id = subnet_id
        self.network_acl_id = network_acl_id

    @property
    def network_acl_association_id(self) -> str:
        return self.id


class NetworkAcl(TaggedEC2Resource):
    def __init__(
        self,
        ec2_backend: Any,
        network_acl_id: str,
        vpc_id: str,
        default: bool = False,
        owner_id: str | None = None,
    ):
        self.ec2_backend = ec2_backend
        self.id = network_acl_id
        self.vpc_id = vpc_id
        self.owner_id = owner_id or ec2_backend.account_id
        self.network_acl_entries: list[NetworkAclEntry] = []
        self._associations: dict[str, NetworkAclAssociation] = {}
        self.default = default

    @property
    def entries(self) -> list["NetworkAclEntry"]:
        return self.network_acl_entries

    @property
    def associations(self) -> list["NetworkAclAssociation"]:
        return list(self._associations.values())

    def get_filter_value(self, filter_name: str, method_name: str | None = None) -> Any:
        if filter_name == "default":
            return str(self.default).lower()
        elif filter_name == "vpc-id":
            return self.vpc_id
        elif filter_name == "association.network-acl-id":
            return self.id
        elif filter_name == "association.association-id":
            return [assoc.new_association_id for assoc in self._associations.values()]
        elif filter_name == "association.subnet-id":
            return [assoc.subnet_id for assoc in self._associations.values()]
        elif filter_name == "entry.cidr":
            return [entry.cidr_block for entry in self.network_acl_entries]
        elif filter_name == "entry.protocol":
            return [entry.protocol for entry in self.network_acl_entries]
        elif filter_name == "entry.rule-number":
            return [str(entry.rule_number) for entry in self.network_acl_entries]
        elif filter_name == "entry.rule-action":
            return [entry.rule_action for entry in self.network_acl_entries]
        elif filter_name == "entry.egress":
            return [str(entry.egress).lower() for entry in self.network_acl_entries]
        elif filter_name == "owner-id":
            return self.owner_id
        else:
            return super().get_filter_value(filter_name, "DescribeNetworkAcls")


class NetworkAclEntry(TaggedEC2Resource):
    def __init__(
        self,
        ec2_backend: Any,
        network_acl_id: str,
        rule_number: int,
        protocol: str,
        rule_action: str,
        egress: bool,
        cidr_block: str,
        icmp_code: int | None,
        icmp_type: int | None,
        port_range_from: int | None,
        port_range_to: int | None,
        ipv6_cidr_block: str | None,
    ):
        self.ec2_backend = ec2_backend
        self.network_acl_id = network_acl_id
        self.rule_number = rule_number
        self.protocol = protocol
        self.rule_action = rule_action
        self.egress = egress
        self.cidr_block = cidr_block
        self.ipv6_cidr_block = ipv6_cidr_block
        self.icmp_code = icmp_code
        self.icmp_type = icmp_type
        self.port_range_from = port_range_from
        self.port_range_to = port_range_to

    @property
    def icmp_type_code(self) -> dict[str, Any] | None:
        if self.icmp_code is not None or self.icmp_type is not None:
            result: dict[str, Any] = {}
            if self.icmp_code is not None:
                result["Code"] = self.icmp_code
            if self.icmp_type is not None:
                result["Type"] = self.icmp_type
            return result
        return None

    @property
    def port_range(self) -> dict[str, Any] | None:
        if self.port_range_from is not None or self.port_range_to is not None:
            return {"From": self.port_range_from, "To": self.port_range_to}
        return None
